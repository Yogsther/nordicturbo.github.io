How to create skins for notu.co Guide (v.2)

Replace every instance of "THEME-NAME" with the name of your theme.
You can use the website_template.psd to try out diffrent designs, and colors.

If you're having any problems, check out the Example folder. Thats how everything should look when you are done.

Naming your theme: 
Make sure you name your theme with either all caps, or with the first letter capital.
ex. Superdark or SUPERDARK

1. Create a card for the theme using the photshop file "THEME-NAME_card.psd"
Make sure you get the right rairty color.

2. Export the THEME-NAME_card as a PNG with transparancy.

3. Edit the THEME-NAME_code.js accordingly. Set your background color and header color. Make sure you replace every 
single THEME-NAME and THEMENAME with the name of your theme.

4. Edit the theme_info.txt with the information about your theme.



!If your theme does not include a banner, you are done here!



4. If you want a banner, export a banner_THEME-NAME.gif or .png (dimentions 1000x90).
You can use the THEME-NAME_banner.psd

5. Make sure you edit in the banenr in the .js file.

6. If you want Music, just include a music file and Olle will fix!
