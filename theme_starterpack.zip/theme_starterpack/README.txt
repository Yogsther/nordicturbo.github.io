How to create skins for notu.co Guide
Replace every instance of "THEME-NAME" with the name of your theme.

1. Create a card for the theme using the photshop file "THEME-NAME_card.psd"
Make sure you get the right rairty color.

2. Export the THEME-NAME_card as a PNG with transparancy.

3. Edit the THEME-NAME_code.js accordingly. Set your background color and header color. Make sure you replace every 
single THEME-NAME and THEMENAME with the name of your theme.



!If your theme does not include a banner, you are done here!



4. If you want a banner, export a banner_THEME-NAME.gif or .png (dimentions 1000x90).
You can use the THEME-NAME_banner.psd

5. Make sure you edit in the banenr in the .js file.

6. You're done, Send in the files in a .zip to the notu.co discord and look forward to seeing this theme in the crates.

